﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


[System.Serializable]
public class ActivateDialog
{
    public bool onCollision;
    public bool onCollisionStayWithDelay;
    public float delay;
    public bool onCollisionAndKeyDown;
    
    public enum OnInput
    {
        disableThisFunction,
        space,
        Down,
        Up,
        Right,
        Left
    }
    public OnInput onInput;
    public bool onFunctionCall;
}
public class ContaningDialog : MonoBehaviour
{
   [SerializeField] ActivateDialog activateDialogWith;
   [SerializeField] List<Dialogs> newDialog = new List<Dialogs>();
   [SerializeField] bool canRepeatTheDialog = false;
   [HideInInspector] public bool canBeActivated = true;
    public bool hasBeenRead = false;
   [HideInInspector] public List<GameObject> siblings = new List<GameObject>();
    bool isInDialogueTrigger = false;
   float delay;
   

    void Start()
    {
        delay = activateDialogWith.delay;
    }
    void OnDestroy()
    {
        for (int x = 0; x < siblings.Count; x++)
        {
            Destroy(siblings[x].gameObject);
        }
    }
    void startConversation()
    {
        DialogManager.Instance.queNewDialog(newDialog, gameObject);
        exitDialogue();
    }
    void exitDialogue()
    {
        if(canRepeatTheDialog)
        {
            Vector3 pos = transform.position;
            Transform parent = transform.parent.transform;

            GameObject newDialogue = Instantiate(gameObject);
            newDialogue.transform.SetParent(parent);
            newDialogue.transform.position = pos;
            newDialogue.name = gameObject.name;
            
            newDialogue.GetComponent<ContaningDialog>().canBeActivated = false;
          

            Destroy(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
    void activateDialoge()
    {
        if (canBeActivated)
            startConversation();
    }
	// Update is called once per frame
	void Update ()
    {
        if (isInDialogueTrigger)
        {
            if (!DialogManager.Instance.isInDialogue)
            {
                activateDialogWith.delay -= Time.deltaTime;
                if (activateDialogWith.delay < 0)
                {
                    if (activateDialogWith.onCollisionStayWithDelay)
                    {
                        activateDialogWith.delay = delay;
                        startConversation();
                    }
                }
            }
        }

        if (activateDialogWith.onInput == ActivateDialog.OnInput.space)
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                startConversation();
            }
        }

    }
    void OnTriggerEnter2D(Collider2D col)
    {
        isInDialogueTrigger = true;
        if (canBeActivated)
        {           
            if (activateDialogWith.onCollision)
            {
                Debug.LogWarning("need to know the players tag");
                startConversation();
            }
        }
    }
    void OnTriggerStay2D(Collider2D col)
    {
       
            Debug.LogWarning("need to know the players tag");
            if (activateDialogWith.onCollisionAndKeyDown)
            {
                if (Input.GetKeyDown(KeyCode.Space))
                {
                startConversation();
            }
            }
    }
    void OnTriggerExit2D(Collider2D col)
    {
        isInDialogueTrigger = false;
        Debug.LogWarning("need to know the players tag");
        canBeActivated = true;
    }
}
